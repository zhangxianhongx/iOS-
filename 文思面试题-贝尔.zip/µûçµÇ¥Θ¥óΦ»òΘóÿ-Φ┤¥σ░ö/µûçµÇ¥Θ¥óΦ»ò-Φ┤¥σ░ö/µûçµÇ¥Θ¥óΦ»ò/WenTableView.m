//
//  WenTableView.m
//  文思面试
//
//  Created by mac on 16/5/18.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import "WenTableView.h"
#import "WenTableViewCell.h"
@implementation WenTableView

- (void)awakeFromNib{
    [super awakeFromNib];
    self.delegate = self;
    self.dataSource = self;
#pragma mark 设置监听
    [self addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
}

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.delegate = self;
        self.dataSource = self;
#pragma mark 设置监听
        [self addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    }
    
    return self;
}

- (id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{
    if (self = [super initWithFrame:frame style:style]) {
        
        self.delegate = self;
        self.dataSource = self;
#pragma mark 设置监听
        [self addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    }
    
    return self;
}


#pragma mark 监听调用的方法
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
//    由于时刻改变太闪，所以此处设置当移动的偏移量是30的倍数时，再改变背景色，这样，在滑动时会有部分cell颜色没改变，但滑动结束会全部一样，总比闪眼看着舒服吧
    if ((NSInteger)self.contentOffset.y % 30 != 0) {
        return;
    }
   int r = rand()%255;
   int g = arc4random()%255;
   int b = arc4random_uniform(255);
//    使用KVC改变所有cell的背景色
    for (int i = 0; i < _dataArray.count; i++) {
        WenTableViewCell *cell = [self cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
       
        [cell setValue:[UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1] forKey:@"backgroundColor"];
    }
    
}
#pragma mark setDataArray
- (void)setDataArray:(NSArray *)dataArray{
    _dataArray = dataArray;
    [self reloadData];
}


#pragma mark tableView dataSource
//row height
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 80;
}
//row count
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
//cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *ID = @"cell";
    
    WenTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[WenTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    
    WenModel *model = [[WenModel alloc] initWithDictionary:_dataArray[indexPath.row]];
    cell.model = model;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}


@end
