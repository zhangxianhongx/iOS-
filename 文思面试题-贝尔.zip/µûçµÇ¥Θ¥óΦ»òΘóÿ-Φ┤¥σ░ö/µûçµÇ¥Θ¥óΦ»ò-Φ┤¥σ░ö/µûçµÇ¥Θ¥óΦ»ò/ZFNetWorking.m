//
//  ZFNetWorking.m
//  文思面试
//
//  Created by mac on 16/5/18.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import "ZFNetWorking.h"

@implementation ZFNetWorking

+ (instancetype)shareInstanceType{
    
    static ZFNetWorking *zfGet = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        zfGet = [[[self class] alloc] init];
    });
    
    return zfGet;
}

- (NSString *)parmasStringWithParmas:(NSDictionary *)parmas{
    
    NSMutableString *parmasString = [[NSMutableString alloc] init];
    
    for (NSString *key in parmas) {
        
        [parmasString appendFormat:@"%@=%@",key,[parmas objectForKey:key]];
        
        if (key != [[parmas allKeys]lastObject]) {
            
            [parmasString appendFormat:@"&"];
        }
        
    }
    
    return parmasString;
}


/*网络请求的三大步骤
 
 1. 设置请求路径 NSURL
 2. 构造一个请求对象 NSURLrequest ：请求体 请求方法 包含请求路径
 3. 发送请求11
 */

- (void)httpRequestWithURL:(NSString *)urlString parmas:(NSDictionary *)parmas httpMethod:(NSString *)method successBackBlock:(void(^)(id responsobject))successBlock fileBackBlock:(void(^)(id reponsobject))fileBlock{
    
    dispatch_queue_t otherThread = dispatch_queue_create("task", DISPATCH_QUEUE_SERIAL);
    
    dispatch_async(otherThread, ^{
        
        //1，设置请求路径
    NSURL *rul = [NSURL URLWithString:urlString];
    //拼接传入参数
    NSString *parmasString = [self parmasStringWithParmas:parmas];
    
    //构建网络请求
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:rul];
    [request setHTTPMethod:method];
    [request setTimeoutInterval:60];
    
    if ([method isEqualToString:@"GET"]) {
        
        //设置请求查询的字符
        NSString *separe = rul.query?@"&":@"?";
        
        NSString *fullString = [NSString stringWithFormat:@"%@%@%@",rul,separe,parmasString];
        //改称UTF8形式
        NSURL *fullUrl = [NSURL URLWithString:[fullString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        
        [request setURL:fullUrl];
        
    }else{
        
        [request setHTTPBody:[parmasString dataUsingEncoding:NSUTF8StringEncoding]];
        
        
    }
    
    
    //3，发送请求
    //    发送同步请求
    //    [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    //2发送异步请求
    NSOperationQueue *mainQueue = [NSOperationQueue mainQueue];
    [NSURLConnection sendAsynchronousRequest:request queue:mainQueue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        if (data) {
            
            id reqestob = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            
            successBlock(reqestob);
        }
        
        if (connectionError) {
            
            fileBlock((NSHTTPURLResponse*)response);
        }
        
        
    }];
        
    });
}

@end
