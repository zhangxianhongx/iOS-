//
//  WenModel.h
//  文思面试
//
//  Created by mac on 16/5/18.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import "BaseModel.h"

@interface WenModel : BaseModel

@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *detailUrl;
@property (nonatomic, copy) NSString *fullCnName;
@property (nonatomic, copy) NSString *logo;
@property (nonatomic, copy) NSNumber *teamId;
@property (nonatomic, copy) NSString *teamName;

@end
