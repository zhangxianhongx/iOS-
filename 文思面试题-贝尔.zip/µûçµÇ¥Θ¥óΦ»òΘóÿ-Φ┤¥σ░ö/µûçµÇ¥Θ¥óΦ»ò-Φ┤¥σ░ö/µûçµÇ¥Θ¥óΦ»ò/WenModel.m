//
//  WenModel.m
//  文思面试
//
//  Created by mac on 16/5/18.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import "WenModel.h"

@implementation WenModel

@end
