//
//  ZFNetWorking.h
//  文思面试
//
//  Created by mac on 16/5/18.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZFNetWorking : NSObject

+ (instancetype)shareInstanceType;

- (void)httpRequestWithURL:(NSString *)urlString parmas:(NSDictionary *)parmas httpMethod:(NSString *)method successBackBlock:(void(^)(id responsobject))successBlock fileBackBlock:(void(^)(id reponsobject))fileBlock;

@end
