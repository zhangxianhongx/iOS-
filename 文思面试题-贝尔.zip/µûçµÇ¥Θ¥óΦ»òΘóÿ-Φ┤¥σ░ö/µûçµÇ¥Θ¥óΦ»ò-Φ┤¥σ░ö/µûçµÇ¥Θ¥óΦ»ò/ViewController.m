//
//  ViewController.m
//  文思面试
//
//  Created by mac on 16/5/18.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import "ViewController.h"
#import "WenTableView.h"
#warning 贝尔原创面试题答案 文思公司2016年招聘题 如要转载或提取本文章代码，请署名贝尔
@interface ViewController ()

@property (nonatomic, strong) WenTableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    _tableView = [[WenTableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    
    [self.view addSubview:_tableView];
    [self loadData];
    

}


#pragma mark loadData
- (void)loadData{
    
    [[ZFNetWorking shareInstanceType] httpRequestWithURL:@"http://sportsnba.qq.com/team/list" parmas:nil httpMethod:@"GET" successBackBlock:^(id responsobject) {
        if ([responsobject isKindOfClass:[NSDictionary class]]&&[[responsobject objectForKey:@"code"] integerValue]==0) {
            
            NSDictionary *dataDic = [responsobject objectForKey:@"data"];
            NSArray *dataArray = [dataDic objectForKey:@"east"];
            NSMutableArray *muDataArray = [[NSMutableArray alloc] init];
            for (int i = 0; i < 3; i++) {
                [muDataArray addObjectsFromArray:dataArray];
            }
            _tableView.dataArray = muDataArray;
            
            
        }
        
        
    } fileBackBlock:^(id reponsobject) {
        
        NSLog(@"请求失败");
    }];
}


@end
