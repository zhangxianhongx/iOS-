//
//  WenTableViewCell.h
//  文思面试
//
//  Created by mac on 16/5/18.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WenModel.h"
@interface WenTableViewCell : UITableViewCell

@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *detLabel;


@property (nonatomic, strong) WenModel *model;

@end
