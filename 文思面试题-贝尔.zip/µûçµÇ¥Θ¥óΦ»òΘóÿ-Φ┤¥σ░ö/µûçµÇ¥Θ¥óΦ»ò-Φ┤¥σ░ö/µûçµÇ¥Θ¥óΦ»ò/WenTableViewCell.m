//
//  WenTableViewCell.m
//  文思面试
//
//  Created by mac on 16/5/18.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import "WenTableViewCell.h"

@implementation WenTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self creatSubViews];

}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self creatSubViews];

    }
    
    return self;
}
//创建cell上的控件
- (void)creatSubViews{
#pragma mark Masonry布局
    _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    _imgView.layer.cornerRadius = _imgView.bounds.size.width/2.0;
    _imgView.layer.masksToBounds = YES;
    [self addSubview:_imgView];
    [_imgView mas_makeConstraints:^(MASConstraintMaker *make) {

        make.top.mas_equalTo(@15);
        make.left.mas_equalTo(@15);
        make.width.mas_equalTo(@50);
        make.height.mas_equalTo(@50);
    }];

    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width-80, 30)];
    [self addSubview:_titleLabel];
    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(@20);
        make.left.mas_equalTo([NSNumber numberWithInt:_imgView.frame.origin.x+_imgView.bounds.size.width+20]);

    }];
    
    _detLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _titleLabel.bounds.size.width, 30)];
    [self addSubview:_detLabel];
    [_detLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo([NSNumber numberWithInt:_titleLabel.bounds.size.height+20]);
        make.left.mas_equalTo([NSNumber numberWithInt:_imgView.frame.origin.x+_imgView.bounds.size.width+20]);
      
    }];
}

- (void)setModel:(WenModel *)model{
    _model = model;
    _titleLabel.text = _model.fullCnName;
    _detLabel.text = [NSString stringWithFormat:@"城市:%@",_model.city];
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:_model.logo]];
    UIImage *image = [UIImage imageWithData:data];
#pragma mark 使用runloop的一种模式及延时调用，使tableView在滑动结束后加装图片，这样可以保证tableView在滑动过程中，不会因为图片的加装而卡顿
     [self.imgView performSelector:@selector(setImage:) withObject:image afterDelay:0 inModes:@[NSDefaultRunLoopMode]];
}
- (void)setImage:(UIImage *)image{
    _imgView.image = image;
    
}



@end
