//
//  BaseModel.h
//  时光电影院
//
//  Created by Mac on 15-7-22.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#warning 本类代码为公司私有财产，严禁做商用，不得私自传播
@interface BaseModel : NSObject
//用于处理特殊字符
@property(nonatomic,strong) NSDictionary *map;

//开放此init方法
- (id)initWithDictionary:(NSDictionary*)dic;
- (void)setAtribute:(NSDictionary *)dic;
@end
