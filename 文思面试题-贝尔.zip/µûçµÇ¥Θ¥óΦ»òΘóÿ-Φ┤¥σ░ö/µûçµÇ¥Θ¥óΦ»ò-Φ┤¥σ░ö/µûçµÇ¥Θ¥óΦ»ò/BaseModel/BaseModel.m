//
//  BaseModel.m
//  时光电影院
//
//  Created by Mac on 15-7-22.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel


- (id)initWithDictionary:(NSDictionary*)dic{
    if (self = [super init]) {
        
        //调用拼写方法名的方法
        [self setAtribute:dic];
    }
    
    
    return self;
}


//拼写方法名，并完成set方法
- (void)setAtribute:(NSDictionary *)dic{
    //取出所有的key
    NSArray *keys = [dic allKeys];
    
    //遍历keys，取出所有的key名
    for (NSString *key in keys) {
        //拼写对应的key值的set方法
        
        //取出key的第一个字母，设置大写
        NSString *a = [[key substringToIndex:1]uppercaseString];
        //拼写方法名
        NSString *mehtodName = [NSString stringWithFormat:@"set%@%@:",a,[key substringFromIndex:1]];

        //将拼写的方法名，转化为方法
        SEL method = NSSelectorFromString(mehtodName);
        //执行该方法
        if ([self respondsToSelector:method]) {
//            非线程调用方法,后面withObject传入的是dic的value
//            [self performSelector:method withObject:[dic objectForKey:key]];
             [self performSelectorOnMainThread:method withObject:[dic objectForKey:key] waitUntilDone:[NSThread isMainThread]];
            
        }
        
    }

    //对特殊字符的特殊处理
    for (NSString *key in self.map) {
        NSString *mehtodName = [self.map objectForKey:key];
        //将拼写的方法名，转化为方法
        SEL method = NSSelectorFromString(mehtodName);
        //执行该方法
        if ([self respondsToSelector:method]) {
            //非线程调用方法,后面withObject传入的是dic的value
//            [self performSelector:method withObject:[dic objectForKey:key]];
             [self performSelectorOnMainThread:method withObject:[dic objectForKey:key] waitUntilDone:[NSThread isMainThread]];
            

        }
        
    }
    
    
}


@end
