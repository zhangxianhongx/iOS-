//
//  UILabel+ChageRunTime.h
//  文思面试
//
//  Created by mac on 16/5/19.
//  Copyright © 2016年 ZY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (ChageRunTime)

@end
